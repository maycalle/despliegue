const Sequelize = require('sequelize');
const express = require('express');
const bodyParser = require('body-parser');

const ModeloArtista = require(__dirname + "/models/artista");
const ModeloCancion = require(__dirname + "/models/cancion");

const routerArtistas = require(__dirname + "/routes/artistas");
const routerCanciones = require(__dirname + "/routes/canciones");

const sequelize = new Sequelize('canciones', 'root', '', {
    host: 'localhost',
    dialect: 'mariadb',
    logging: false,
    pool: {
        max: 10,
        min: 0,
        acquire: 30000,
        idle: 10000
    }
});

const Artista = ModeloArtista(sequelize, Sequelize);
const Cancion = ModeloCancion(sequelize, Sequelize);

Cancion.belongsTo(Artista, {foreignKey: 'idArtista', as: 'Artista'});

const artistas = routerArtistas(express, Artista);
const canciones = routerCanciones(express, Cancion, Artista);

let app = express();

app.use(bodyParser.json());
app.use('/canciones', canciones);
app.use('/artistas', artistas);

sequelize.sync()
.then(() => {
    app.listen(8080);
}).catch (error => {
    console.log(error);
});