/* 
Archivo con constantes de texto en castellano 
*/

const textos = require(__dirname + '/saludos.json');

module.exports = {
    saludo : textos.es
};