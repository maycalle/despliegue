/* 
Programa principal para el módulo de utilidades 
*/

const utilidades = require(__dirname + '/utilidades');
console.log(utilidades.sumar(3, 2));
console.log(utilidades.pi);