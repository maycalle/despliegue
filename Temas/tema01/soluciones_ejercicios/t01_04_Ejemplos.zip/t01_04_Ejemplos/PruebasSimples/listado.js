/*
Ejemplo de uso de librerías del núcleo de Node.
Empleamos la librería "fs" para listar los archivos y carpetas de una ruta dada
*/

const ruta = "/Users/nacho";
const fs = require('fs');
fs.readdirSync(ruta).forEach(fichero => { console.log(fichero); });