/*
Ejercicio para definir unos servicios REST sobre un catálogo de libros
*/

const express = require('express');
const bodyParser = require('body-parser');
const fichUtils = require(__dirname + '/fichero_utils.js');

// Definimos el catálogo a mano en el código
/*
let libros = [
    {id: 1, titulo: "El juego de Ender", autor: "Orson Scott Card", precio: 7.95},
    {id: 2, titulo: "El Señor de los Anillos", autor: "J.R.R. Tolkien", precio: 19.90},
    {id: 3, titulo: "La tabla de Flandes", autor: "Arturo Pérez Reverte", precio: 8.50},
    {id: 4, titulo: "La historia interminable", autor: "Michael Ende", precio: 12.35}
];
*/

let app = express();

let libros = fichUtils.cargarLibros();

app.use(bodyParser.json());

/* Servicio GET para obtener todos los libros */
app.get('/libros', (req, res) => {
    if (libros && libros.length > 0) {
        res.status(200)
           .send({ ok: true, libros: libros});
    } else {
        // Si algo falla es porque el servidor no ha podido recuperar la
        // lista de libros, fallo del servidor (500)
        res.status(500)
           .send({ ok: false, error: "No se encontraron libros"});
    }
});

/* Servicio para obtener un libro a partir de su id */
app.get('/libros/:id', (req, res) => {
    let resultado = libros.filter(
        libro => libro.id == req.params['id']
    );
    if (resultado.length > 0) {
        res.status(200)
           .send({ ok: true, resultado: resultado[0]});    
    } else {
        // En este caso, si no se encuentra nada es porque el id
        // indicado en la URL es equivocado, fallo del cliente (400)
        res.status(400)
           .send({ ok: false, error: "No se encontró el libro indicado"});
    }
});

// POST para añadir nuevos libros
app.post('/libros', (req, res) => {

    let nuevoLibro = {
        id: req.body.id,
        titulo: req.body.titulo,
        autor: req.body.autor,
        precio: req.body.precio
    };

    let existe = libros.filter(
        libro => libro.id == nuevoLibro.id
    );
    
    if (existe.length == 0) {
        // No existe libro. Añadimos y enviamos OK
        libros.push(nuevoLibro);
        fichUtils.guardarLibros(libros);
        res.status(200).send({ok: true});
    } else {
        // El libro ya existe. Enviamos error
        res.status(400).send({ok: false,
                              error: "Libro duplicado"});
    }    
});

// PUT para editar un libro a partir de su id
app.put('/libros/:id', (req, res) => {
    let existe = libros.filter(
        libro => libro.id == req.params['id']
    );

    if (existe.length > 0) {
        // El libro existe. Lo modificamos y enviamos OK
        let libro = existe[0];
        libro.titulo = req.body.titulo;
        libro.autor = req.body.autor;
        libro.precio = req.body.precio;
        fichUtils.guardarLibros(libros);
        res.status(200).send({ok: true});
    } else {
        res.status(400).send({ok: false,
                              error: "Libro no encontrado"});
    }
});

// DELETE para borrar un libro a partir de su id
app.delete('/libros/:id', (req, res) => {
    let filtrado = libros.filter(
        libro => libro.id != req.params['id']
    );

    if (filtrado.length != libros.length) {
        // El libro existe. Reemplazamos el array y OK
        libros = filtrado;
        fichUtils.guardarLibros(libros);
        res.status(200).send({ok: true});
    } else {
        // No se ha filtrado nada. El libro no existe
        res.status(400).send({ok: false,
                              error: "Libro no encontrado"});
    }
});


app.listen(8080);
