var socket = io('http://localhost:8080');

socket.on('conectado', function() {
    alert("Conectado");
    document.getElementById('formulario').style.display = "";
});

function enviar() {
    var nick = document.getElementById('nick').value;
    var texto = document.getElementById('texto').value;
    if (texto != "" && nick != "")
        socket.emit('enviar', {nick: nick, texto: texto});
}

socket.on('difundir', function(datos) {
    var chat = document.getElementById('chat');
    chat.innerHTML += '<p><em>' + datos.nick + '</em>: ' + datos.texto + '</p>';
});

socket.on('disconnect', function() {
    alert("Servidor desconectado");
});
