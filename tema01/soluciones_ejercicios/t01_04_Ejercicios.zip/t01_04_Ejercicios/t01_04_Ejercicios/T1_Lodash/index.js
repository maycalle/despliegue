/* 
Ejercicio: utilizar el módulo de terceros "lodash" para sacar unidos
por comas los nombres de un vector 
*/

const _ = require('lodash');
const nombres = ["Nacho", "Ana", "Mario", "Laura"];
console.log(_.join(nombres, ","));
