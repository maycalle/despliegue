/*
Ejemplo de servicios REST sobre una lista de contactos
*/

const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

/*
let contactos = [
    {nombre: "Nacho", edad: 41, telefono: "611223344"},    
    {nombre: "Ana", edad: 37, telefono: "699887766"},    
    {nombre: "Juan", edad: 70, telefono: "965661564"},    
    {nombre: "Fina", edad: 68, telefono: "965262861"},    
    {nombre: "Enrique", edad: 12, telefono: "965262861"},    
    {nombre: "Pepe", edad: 15, telefono: "966555555"}
];
*/

let cargarContactos = () => {
    let contactos = [];
    if (fs.existsSync('contactos.json'))
        contactos =
            JSON.parse(fs.readFileSync('contactos.json', 'utf8'));
    return contactos;
};

let guardarContactos = (contactos) => {
fs.writeFileSync('contactos.json', JSON.stringify(contactos));
};

let app = express();

contactos = cargarContactos();

app.use(bodyParser.json());

// GET para todos los contactos
app.get('/contactos', (req, res) => {
    if (contactos && contactos.length > 0) {
        res.status(200)
           .send({ ok: true, contactos: contactos});
    } else {
        // Si algo falla es porque el servidor no ha podido recuperar la
        // lista de contactos, fallo del servidor (500)
        res.status(500)
           .send({ ok: false, error: "No se encontraron contactos"});
    }
});


// GET para contactos a partir de su teléfono
app.get('/contactos/telefono/:numero', (req, res) => {
    let resultado = contactos.filter(
        contacto => contacto.telefono == req.params['numero']
    );
    
    if (resultado && resultado.length > 0) {
        res.status(200)
           .send({ ok: true, resultado: resultado});
    } else {
        // En este caso, si no se encuentra nada es porque el teléfono
        // indicado en la URL es equivocado, fallo del cliente (400)
        res.status(400)
           .send({ ok: false, error: "No se encontraron contactos"});
    }    
});

// POST para añadir nuevos contactos
app.post('/contactos', (req, res) => {

    let nuevoContacto = {
        nombre: req.body.nombre,
        edad: req.body.edad,
        telefono: req.body.telefono
    };

    let existe = contactos.filter(
        contacto => contacto.nombre == nuevoContacto.nombre
    );
    
    if (existe.length == 0) {
        // No existe contacto. Añadimos y enviamos OK
        contactos.push(nuevoContacto);
        guardarContactos(contactos);
        res.status(200).send({ok: true});
    } else {
        // El contacto ya existe. Enviamos error
        res.status(400).send({ok: false,
                              error: "Contacto duplicado"});
    }    
});

// PUT para editar un contacto a partir de su nombre
app.put('/contactos/:nombre', (req, res) => {
    let existe = contactos.filter(
        contacto => contacto.nombre == req.params['nombre']
    );

    if (existe.length > 0) {
        // El contacto existe. Lo modificamos y enviamos OK
        let contacto = existe[0];
        contacto.nombre = req.body.nombre;
        contacto.edad = req.body.edad;
        contacto.telefono = req.body.telefono;
        guardarContactos(contactos);
        res.status(200).send({ok: true});
    } else {
        res.status(400).send({ok: false,
                              error: "Contacto no encontrado"});
    }
});

// DELETE para borrar un contacto a partir de su nombre
app.delete('/contactos/:nombre', (req, res) => {
    let filtrado = contactos.filter(
        contacto => contacto.nombre != req.params['nombre']
    );

    if (filtrado.length != contactos.length) {
        // El contacto existe. Reemplazamos el array y OK
        contactos = filtrado;
        guardarContactos(contactos);
        res.status(200).send({ok: true});
    } else {
        // No se ha filtrado nada. El contacto no existe
        res.status(400).send({ok: false,
                              error: "Contacto no encontrado"});
    }
});

app.listen(8080);
