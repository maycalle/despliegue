/*
Ejemplos sencillos de tratamiento de datos en formato JSON
*/

// Incluimos librería para cargar/guardar datos de/en fichero
const fs = require('fs');

// Array de datos de prueba
let personas = [
    { nombre: "Nacho", edad: 42},
    { nombre: "Mario", edad: 4},
    { nombre: "Laura", edad: 2},
    { nombre: "Nora", edad: 10}
];

// Convertir JavaScript a JSON
let personasJSON = JSON.stringify(personas);
console.log("Cadena JSON:", personasJSON);

// Convertir JSON a JavaScript
let personas2 = JSON.parse(personasJSON);
console.log("Objeto JavaScript:", personas2);

// Guardar y cargar datos de fichero
fs.writeFileSync("personas.txt", JSON.stringify(personas));
let personasFichero = JSON.parse(fs.readFileSync("personas.txt", 'utf8'));
console.log("Objeto leído de fichero:", personasFichero);