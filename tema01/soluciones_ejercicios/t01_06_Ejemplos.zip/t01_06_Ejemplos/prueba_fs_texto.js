/*
Ejemplo de lectura y escritura de texto en archivos con Node.js
*/

const fs = require('fs');

const archivo = "datos.txt";
const textoPredefinido = "En un lugar de la mancha\n" +
                         "de cuyo nombre no quiero acordarme";

let guardarDatos = () => {
    fs.writeFileSync(archivo, textoPredefinido);
};

let leerDatos = () => {
    return fs.readFileSync(archivo, 'utf-8');
};

// Programa principal
guardarDatos();
console.log("Texto del fichero:");
console.log(leerDatos());
