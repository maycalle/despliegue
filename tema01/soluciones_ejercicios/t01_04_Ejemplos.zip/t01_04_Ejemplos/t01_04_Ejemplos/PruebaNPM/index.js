/* 
Ejemplo de instalación y uso de módulos de terceros: lodash 
*/

const lodash = require('lodash');
console.log(lodash.difference([1, 2, 3], [1]));