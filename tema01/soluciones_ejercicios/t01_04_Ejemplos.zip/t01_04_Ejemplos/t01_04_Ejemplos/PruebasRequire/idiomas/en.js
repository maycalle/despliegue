/* 
Archivo con constantes de texto en inglés 
*/

const textos = require(__dirname + '/saludos.json');

module.exports = {
    saludo : textos.en
};