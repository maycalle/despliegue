/* 
Programa principal para saludar en varios idiomas 
*/

const idiomas = require(__dirname + '/idiomas');

console.log("English:", idiomas.en.saludo);
console.log("Español:", idiomas.es.saludo);