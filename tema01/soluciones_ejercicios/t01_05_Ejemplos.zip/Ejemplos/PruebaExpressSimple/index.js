/*
Prueba simple de uso de Express para conectar a 
una ruta raíz que emite un mensaje de bienvenida
*/

const express = require('express');

let app = express();

app.get('/', (req, res) => {
    res.send("Bienvenido/a");
});

app.listen(8080);