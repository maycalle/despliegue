/*
Ejercicio para definir unos servicios de búsqueda sobre un catálogo de libros
*/

const express = require('express');

// Definimos el catálogo a mano en el código
let libros = [
    {id: 1, titulo: "El juego de Ender", autor: "Orson Scott Card", precio: 7.95},
    {id: 2, titulo: "El Señor de los Anillos", autor: "J.R.R. Tolkien", precio: 19.90},
    {id: 3, titulo: "La tabla de Flandes", autor: "Arturo Pérez Reverte", precio: 8.50},
    {id: 4, titulo: "La historia interminable", autor: "Michael Ende", precio: 12.35}
];

let app = express();

/* Servicio para obtener todos los libros */
app.get('/libros', (req, res) => {
    res.send(libros);
});

/* Servicio para obtener un libro a partir de su id */
app.get('/libros/:id', (req, res) => {
    let resultado = libros.filter(
        libro => libro.id == req.params['id']
    );
    if (resultado.length > 0)
        res.send(resultado[0]);
    else
        res.send("Libro no encontrado");
});

app.listen(8080);
