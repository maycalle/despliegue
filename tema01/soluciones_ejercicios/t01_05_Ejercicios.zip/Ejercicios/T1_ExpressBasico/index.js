/*
Ejercicio para probar un servidor básico de Express con un par de rutas simples
*/ 

const express = require('express');
const os = require('os');

let app = express();

/* Ruta para la fecha actual */
app.get('/fecha', (req, res) => {
    res.send("Fecha actual: " + new Date());
});

/* Ruta para el usuario actual */
app.get('/usuario', (req, res) => {
    res.send("El usuario es: " + os.userInfo().username);
});

app.listen(8080);