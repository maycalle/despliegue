/*
Ejemplo de uso de callbacks: la función "setTimeOut"
*/

setTimeout(function() {console.log("Finalizado callback");}, 2000);
console.log("Hola");