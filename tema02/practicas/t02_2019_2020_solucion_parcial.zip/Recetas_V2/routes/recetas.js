const express = require('express');

let Receta = require(__dirname + '/../models/receta.js')
let router = express.Router();

// Servicio de listado
router.get('/', (req, res) => {
    Receta.find().populate('elementos.ingrediente').then(resultado => {
        res.status(200)
           .send({ok: true, resultado: resultado});
    }).catch (error => {
        res.status(500)
           .send({ok: false, error: "Error obteniendo recetas"});
    });
});

// Servicio de inserción
router.post('/', (req, res) => {
    let nuevaReceta = new Receta({
        titulo: req.body.titulo,
        comensales: req.body.comensales,
        preparacion: req.body.preparacion,
        coccion: req.body.coccion,
        descripcion: req.body.descripcion
    });

    nuevaReceta.save().then(resultado => {
        res.status(200)
           .send({ok: true, resultado: resultado});
    }).catch(error => {
        res.status(400)
           .send({ok: false, error: "Error añadiendo receta"});
    });
});

// Servicio de borrado
router.delete('/:id', (req,res) => {
    Receta.findByIdAndRemote(req.params['id']).then(resultado => {
        res.status(200)
           .send({ ok: true, resultado: resultadoIng });
    }).catch (error =>  {
        res.status(400)
           .send({ ok: false, error: "Error eliminando ingrediente"});
    });
});

// Servicio de insercion (añadir ingredientes)
router.post('/elementos/:id', (req, res) => {
    Receta.findById(req.params['id']).then(resultado => {
        let nuevoElemento = {
            ingrediente: req.body.ingrediente,
            cantidad: req.body.cantidad,
            unidad: req.body.unidad
        };
        resultado.elementos.push(nuevoElemento);
        resultado.save().then(resultado2 => {
            res.status(200)
               .send({ ok: true, resultado: resultado2});
        }).catch(error => {
            res.status(400)
               .send({ ok: false, error: "Error añadiendo elemento a receta"});
        });
    }).catch(error => {
        res.status(400)
           .send({ ok: false, error: "Error, receta no encontrada"});
    });
});

// Servicio de borrado (eliminar elementos de receta)
router.delete('/elementos/:id/:idIngrediente', (req, res) => {
    Receta.findById(req.params['id']).then(resultado => {
        let nuevosElementos = resultado.elementos.filter(elemento => elemento.ingrediente != req.params['idIngrediente']);
        if (nuevosElementos.length != resultado.elementos.length) {
            resultado.elementos = nuevosElementos;
            resultado.save().then(resultado2 => {
                res.status(200)
                   .send({ ok: true, resultado: resultado2 });
            }).catch(error => {
                res.status(400)
                   .send({ ok: false, error: "Error eliminando elemento"});
            });
        } else {
            res.status(400)
               .send({ ok: false, error: "Elemento no encontrado"});
        }
    }).catch(error => {
        res.status(400)
           .send({ ok: false, error: "Error, receta no encontrada"});
    });
})

module.exports = router;