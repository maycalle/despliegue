const express = require('express');

let Ingrediente = require(__dirname + '/../models/ingrediente.js');
let Receta = require(__dirname + '/../models/receta.js')
let router = express.Router();

// Servicio de listado
router.get('/', (req, res) => {
    Ingrediente.find().then(resultado => {
        res.status(200)
           .send({ok: true, resultado: resultado});
    }).catch (error => {
        res.status(500)
           .send({ok: false, error: "Error obteniendo ingredientes"});
    });
});

// Servicio de inserción
router.post('/', (req, res) => {
    let nuevoIngrediente = new Ingrediente({
        nombre: req.body.nombre,
        tipo: req.body.tipo
    });

    nuevoIngrediente.save().then(resultado => {
        res.status(200)
           .send({ok: true, resultado: resultado});
    }).catch(error => {
        res.status(400)
           .send({ok: false, error: "Error añadiendo ingrediente"});
    });
});

// Servicio de borrado
router.delete('/:id', (req,res) => {
    Receta.find().then(resultado => {
        let existenRecetas = resultado.filter(receta => {
            let existeIng = receta.elementos.filter(elemento =>  elemento.ingrediente == req.params['id']);
            return existeIng.length > 0;
        });

        if (existenRecetas.length == 0) {
            Ingrediente.findByIdAndRemove(req.params['id']).then(resultadoIng => {
                res.status(200)
                   .send({ ok: true, resultado: resultadoIng });
            }).catch (error =>  {
                res.status(400)
                   .send({ ok: false, error: "Error eliminando ingrediente"});
            });
        } else {
            res.status(400)
               .send({ ok: false, error: "Ingrediente existente en receta"});
        }
    }).catch(error => {
        res.status(500)
           .send({ok: false, error: "Error eliminando ingrediente"});
    })
});

module.exports = router;