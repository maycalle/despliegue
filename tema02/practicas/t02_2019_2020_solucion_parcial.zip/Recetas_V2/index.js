// Carga de librerías
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// Enrutadores
const recetas = require(__dirname + '/routes/recetas');
const ingredientes = require(__dirname + '/routes/ingredientes');

// Conectar con BD en Mongo 
mongoose.connect('mongodb://localhost:27017/recetas', {useNewUrlParser: true});

// Inicializar Express
let app = express();

// Cargar middleware body-parser para peticiones POST y PUT
// y enrutadores
app.use(bodyParser.json());
app.use('/recetas', recetas);
app.use('/ingredientes', ingredientes) 

// Puesta en marcha del servidor
app.listen(8080);