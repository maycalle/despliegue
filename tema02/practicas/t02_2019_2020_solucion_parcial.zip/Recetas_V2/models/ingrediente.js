const mongoose = require('mongoose');

let ingredienteSchema = new mongoose.Schema({
    nombre: {
        type: String,
        required: true,
        minlength: 2,
        trim: true
    },
    tipo: {
        type: String,
        required: true,
        enum: ["carne", "pescado", "frutas y verduras", "arroces y pastas", "otros"]
    }
});

let Ingrediente = mongoose.model('ingrediente', ingredienteSchema);

module.exports = Ingrediente;