const mongoose = require('mongoose');

let elementoRecetaSchema = new mongoose.Schema({
    ingrediente: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ingrediente'
    },
    cantidad: {
        type: Number,
        required: true,
        min: 1
    },
    unidad: {
        type: String,
        required: true,
        minlength: 5,
        trim: true
    }

});

let recetaSchema = new mongoose.Schema({
    titulo: {
        type: String,
        required: true,
        minlength: 5,
        trim: true
    },
    comensales: {
        type: Number,
        required: true,
        min: 1
    },
    preparacion: {
        type: Number,
        required: true,
        min: 1
    },
    coccion: {
        type: Number,
        required: true,
        min: 0
    },
    descripcion: {
        type: String,
        required: true
    },
    elementos: {
        type: [elementoRecetaSchema]
    }
});

let Receta = mongoose.model('receta', recetaSchema);

module.exports = Receta;