const express = require('express');
const mysql = require('mysql');

let conexion = mysql.createConnection({
    host: 'localhost', 
    user: 'root',
    password: '',
    database: 'cursos'
});

let app = express();
app.use(express.json());

app.get('/cursos', (req, res) => {
    conexion.query("SELECT * FROM cursos", (error, resultado, campos) =>
    {
        if (error)
            res.status(500).send({ok: false, error: "Error llistant cursos"});
        else
            res.status(200).send({ok: true, resultado: resultado});
    });
});

app.get('/alumnes/:curs', (req, res) => {
    conexion.query("SELECT * FROM alumnes WHERE curs = ?", req.params['curs'], (error, resultado, campos) =>
    {
        if (error)
            res.status(500).send({ok: false, error: "Error llistant alumnes"});
        else
            res.status(200).send({ok: true, resultado: resultado});
    });
});

app.post('/cursos', (req, res) => {
    let nouCurs = {
        nom: req.body.nom,
        aula: req.body.aula
    };

    conexion.query("INSERT INTO cursos SET ?", nouCurs, (error, resultado, campos) =>
    {
        if (error)
        {
            res.status(400).send({ok: false, error: "Error afegint curs"});
            console.log(error);
        }
        else
            res.status(200).send({ok: true, resultado: resultado});
    });
});

app.post('/alumnes', (req, res) => {
    let nouAlumne = {
        nom: req.body.nom,
        nia: req.body.nia,
        naixement: req.body.naixement,
        curs: req.body.curs
    };

    conexion.query("SELECT * FROM cursos WHERE id = ?", nouAlumne.curs, (error, resultado, campos) =>
    {
        if (!error && resultado.length > 0)
        {
            conexion.query("INSERT INTO alumnes SET ?", nouAlumne, (error, resultado, campos) =>
            {
                if (error)
                {
                    res.status(400).send({ok: false, error: "Error afegint curs"});
                    console.log(error);
                }
                else
                    res.status(200).send({ok: true, resultado: resultado});
            });
        }
        else
        {
            res.status(400).send({ ok: false, error: "Error afegint alumne. Curs invàlid o dades invàlides"});
        }
    });
});

app.delete('/cursos/:id', (req, res) => {

    conexion.query("DELETE FROM alumnes WHERE curs = ?", req.params['id'], (error, resultado, campos) => {
        if (error)
        {
            res.status(400).send({ok: false, error: "Error esborrant alumnes"});
            console.log(error);
        }
        else
        {
            conexion.query("DELETE FROM cursos WHERE id = ?", req.params['id'], (error, resultado, campos) => {
                if (error)
                {
                    res.status(400).send({ok: false, error: "Error esborrant curs"});
                    console.log(error);
                }
                else
                    res.status(200).send({ok: true, resultado: resultado});
            });
        }    
    });
});

app.delete('/alumnes/:id', (req, res) => {
    conexion.query("DELETE FROM alumnes WHERE id = ?", req.params['id'], (error, resultado, campos) => {
        if (error)
        {
            res.status(400).send({ok: false, error: "Error esborrant alumne"});
            console.log(error);
        }
        else
            res.status(200).send({ok: true, resultado: resultado});
    })
});

app.get('/alumnes/aula/:id', (req, res) => {
    conexion.query("SELECT cursos.aula FROM alumnes, cursos WHERE alumnes.curs = cursos.id AND alumnes.id = ?", req.params['id'], (error, resultado, campos) => {
        if (error || resultado.length == 0)
        {
            res.status(400).send({ok: false, error: "Error buscant alumne"});
            console.log(error);
        }
        else
            res.status(200).send({ok: true, resultado: resultado});
    });
});

app.get('/cursos/:id/:any', (req, res) => {
    conexion.query("SELECT * FROM alumnes WHERE curs = ? AND naixement = ?", [req.params['id'], req.params['any']], (error, resultado, campos) => {
        if (error || resultado.length == 0)
        {
            res.status(400).send({ok: false, error: "Error buscant alumnes"});
            console.log(error);
        }
        else
            res.status(200).send({ok: true, resultado: resultado});
    });
});

app.listen(8080);