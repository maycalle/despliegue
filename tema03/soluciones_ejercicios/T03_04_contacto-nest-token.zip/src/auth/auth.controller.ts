import { Body, Controller, HttpStatus, Post, UnauthorizedException, ValidationPipe } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/login-dto';

@Controller('auth')
export class AuthController {
    constructor(private readonly authService: AuthService) {}

    @Post('login')
    async login(
      @Body(new ValidationPipe({ whitelist: true }))
      userDto: LoginDto
    ) {
        return await this.authService.login(userDto);
    }
}
