export const jwtConstants = {
    secret: 'WEr34fwGter',
};