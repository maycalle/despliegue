import { TareaDto } from './tarea-dto';

describe('TareaDto', () => {
  it('should be defined', () => {
    expect(new TareaDto()).toBeDefined();
  });
});
