export class TareaDto {
    id: string;
    nombre: string;
    prioridad: number;
    fecha: Date;
}
