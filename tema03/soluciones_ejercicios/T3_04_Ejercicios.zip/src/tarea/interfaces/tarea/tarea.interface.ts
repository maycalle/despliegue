export interface Tarea {
    id: string;
    nombre: string;
    prioridad: number;
    fecha: Date;
}
