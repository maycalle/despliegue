export class ContactoDto {
    readonly nombre: string;
    readonly edad: number;
    readonly telefono: string;
}
