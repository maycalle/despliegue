import { ContactoDto } from './contacto-dto';

describe('ContactoDto', () => {
  it('should be defined', () => {
    expect(new ContactoDto()).toBeDefined();
  });
});
