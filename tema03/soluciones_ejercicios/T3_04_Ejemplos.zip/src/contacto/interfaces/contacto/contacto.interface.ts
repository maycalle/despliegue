export interface Contacto {
    id: string;
    nombre: string;
    edad: number;
    telefono: string;
}
